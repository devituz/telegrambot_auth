<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


Route::prefix('bot')->group(function () {
    Route::post('/telegram/update', 'App\Http\Controllers\REST\Telegram\TelegramUpdateController');
    \Log::info('asfdasd');
});


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

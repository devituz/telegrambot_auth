<?php


if (!function_exists('nlog_error')) {
    function nlog_error(\Exception $e): void
    {
        \Log::error("\n\n\n"
            . "\nMsg: " . $e->getMessage()
            . "\nFile: " . $e->getFile()
            . "\nLine: " . $e->getLine()
            . "\n\n\n");
    }
}

if (!function_exists('nlog_debug')) {
    function nlog_debug(string $message): void
    {
        \Log::debug("\n\n\n" . "\nMsg: " . $message . "\n\n\n");
    }
}

<?php

namespace App\Telegram;

use App\Models\User;
use App\Repositories\Core\UserRepository;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Log;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Types\User\User as TelegramUser;

class TelegramService
{

    public function setWebhook(): array
    {
        $url = "https://api.telegram.org/bot" . config('nutgram.token');
        $url .= "/setWebhook?url=" . config('nutgram.webhook_domain') . config('nutgram.webhook_url');

        try {
            $response = Http::get($url);
            $result = ['success' => $response->ok(), 'body' => $response->json()];
        } catch (\Throwable $th) {
            $result['error'] = $th->getMessage();
        }
        return $result;
    }

    public function saveUserWithContact(Nutgram $bot): null|string
    {
        $user = new User();
        $user->phone = $bot->message()->contact->phone_number;
        $user->firstname = $bot->user()->first_name;
        $user->lastname = $bot->user()->last_name ?? '';
        $user->username = $bot->user()->username ?? '';

        $password = (string)rand(100000, 999999);
        $user->password = $password;

        $newUser = (new UserRepository())->createUser($user);

        if ($newUser->exists()) {
            $newPassword = '';
            for ($i = 0; $i < strlen($password); $i++)
                $newPassword .= $password[$i] . ' ';

            return $newPassword;
        }

        return null;
    }

    public function login(Nutgram $bot): null
    {
        $user = new User();
        $user->phone = $bot->message()->contact->phone_number;
        $user->firstname = $bot->user()->first_name;
        $user->lastname = $bot->user()->last_name ?? '';
        $user->username = $bot->user()->username ?? '';

        $password = (string)rand(100000, 999999);
        $user->password = $password;

        $newUser = (new UserRepository())->createUser($user);

        return null;
    }

}

<?php

namespace App\Telegram\Commands;

use Illuminate\Support\Facades\App;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Handlers\Type\Command;
use SergiX44\Nutgram\Telegram\Properties\ParseMode;

class Login extends Command
{
    protected string $command = 'login';

    protected ?string $description = 'A lovely description.';

    public function handle(Nutgram $bot): void
    {
        // $bot->sendMessage(text: "🔒 Kodingiz: \n\n 1 2 3 4 5 6 \n\n 🔑 Yangi kod olish uchun /login ni bosing" . $phone_number);


        try {
            $password = (string)rand(100000, 999999);

            /*$bot->sendMessage(
                text: '*Hi*',
                parse_mode: ParseMode::MARKDOWN
            );*/
            $newPassword = '';
            for ($i = 0; $i < strlen($password); $i++) {
                $newPassword .= $password[$i] . ' ';
            }

            $bot->sendMessage(
                text: "🔒 Kodingiz: \n\n <code> $newPassword </code> \n\n 🔑 Yangi kod olish uchun /login ni bosing",
                parse_mode: ParseMode::HTML,
            );
        } catch (\Exception $e) {
            \Log::error($e->getMessage());
        }

    }
}

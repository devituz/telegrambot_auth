<?php

namespace App\Telegram\Commands;

use Nutgram\Laravel\Facades\Telegram;
use SergiX44\Nutgram\Handlers\Type\Command;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Types\Keyboard\KeyboardButton;
use SergiX44\Nutgram\Telegram\Types\Keyboard\ReplyKeyboardMarkup;

class Start extends Command
{
    protected string $command = 'start';

    protected ?string $description = 'A lovely description.';

    public function handle(Nutgram $bot): void
    {
        $first_name = $bot->user()->first_name;
        Telegram::sendMessage(
            text: "Salom  $first_name 👋 \n\n@datadevuz rasmiy botiga xush kelibsiz \n\n⬇️ Kontaktingizni yuboring (tugmani bosib)",
            reply_markup: ReplyKeyboardMarkup::make(resize_keyboard:  true, one_time_keyboard: true, is_persistent: true)
                ->addRow(
                    KeyboardButton::make(text: "☎️ Kontaktni yuborish", request_contact: true)
                )
        );
    }
}

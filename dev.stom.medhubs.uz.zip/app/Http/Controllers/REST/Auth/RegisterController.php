<?php

namespace App\Http\Controllers\REST\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterRequest;
use App\Services\REST\RegisterService;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    protected RegisterService $service;

    public function __construct(RegisterService $service)
    {
        $this->service = $service;
    }

    function register(RegisterRequest $request)
    {

    }
}

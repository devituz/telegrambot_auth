<?php

namespace App\Http\Controllers\REST\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LoginController extends Controller
{

    function login(Request $request)
    {
        \Log::info('alasdlsafd');

        dd($request);
    }

}

<?php

namespace App\Services\Core;

use App\Models\Phone;
use App\Models\User;
use App\Repositories\Core\PhoneRepository;
use App\Repositories\Core\UserRepository;
use App\Services\BaseService;
use Illuminate\Auth\Events\Registered;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

/**
 * @author NurbekMakhmudov
 */
class AuthService extends BaseService
{
    protected UserRepository $userRepository;
    protected PhoneRepository $phoneRepository;

    public function __construct(UserRepository $userRepository, PhoneRepository $phoneRepository)
    {
        $this->userRepository = $userRepository;
        $this->phoneRepository = $phoneRepository;
    }

    protected function getPhone(string $number): Model|null
    {
        return $this->phoneRepository->getModelByColumnValue('number', $number);
    }

    protected function getUserById($id): Model|null
    {
        return $this->userRepository->getModelById($id);
    }

    private function storeWeb(array $data): bool
    {

        if (!Hash::check($data['password'], $user->password)) {
            Session::flash('error_password', __("Parol noto'g'ri"));
            return false;
        }

        event(new Registered($user));
        Auth::login($user);

        return true;
    }

    private function storeApi(array $data): \Illuminate\Http\JsonResponse
    {
        /** @var Phone $phone */
        $phone = $this->phoneRepository->getModelByColumnValue('number', clearPhone($data['phone']));
        if (is_null($phone)) {
            return response()->json([
                'success' => false,
                'data' => [
                    'error' => "Telefon raqam noto'g'ri"
                ]
            ]);
        }

        /** @var User $user */
        $user = $this->userRepository->getModelById($phone->user_id);
        if (is_null($user)) {
            return response()->json([
                'success' => false,
                'data' => [
                    'error' => "Foydalanuvchi telefon raqam bo'yicha topilmadi"
                ]
            ]);
        }

        if (!Hash::check($data['password'], $user->password)) {
            return response()->json([
                'success' => false,
                'data' => [
                    'error' => "Parol noto'g'ri"
                ]
            ]);
        }

        $token = $user->createToken($user->firstname . '-AuthToken')->plainTextToken;
        return response()->json([
            'success' => true,
            'data' => [
                'token' => $token
            ]
        ]);
    }
}

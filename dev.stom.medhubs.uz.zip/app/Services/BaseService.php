<?php

namespace App\Services;

class BaseService
{

}

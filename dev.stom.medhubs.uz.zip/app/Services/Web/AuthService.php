<?php

namespace App\Services\Web;

use App\Models\Phone;
use App\Models\User;
use App\Services\Core\AuthService as Core;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class AuthService extends Core
{
    public function store(array $data): bool
    {
        /** @var Phone $phone */
        $phone = $this->getPhone(clearPhone($data['phone']));
        if (is_null($phone)) {
            Session::flash('error_phone', __("Telefon raqam noto'g'ri"));
            return false;
        }

        /** @var User $user */
        $user = $this->getUserById($phone->user_id);
        if (is_null($user)) {
            Session::flash('error_phone', __("Foydalanuvchi telefon raqam bo'yicha topilmadi"));
            return false;
        }

        if (!Hash::check($data['password'], $user->password)) {
            Session::flash('error_password', __("Parol noto'g'ri"));
            return false;
        }

        event(new Registered($user));
        Auth::login($user);

        return true;
    }


}

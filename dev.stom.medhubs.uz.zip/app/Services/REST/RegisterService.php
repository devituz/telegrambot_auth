<?php

namespace App\Services\REST;

use App\Models\Phone;
use App\Models\User;
use App\Repositories\Core\PhoneRepository;
use App\Repositories\Core\UserRepository;
use Illuminate\Support\Facades\Hash;

class RegisterService
{
    protected UserRepository $userRepository;
    protected PhoneRepository $phoneRepository;

    public function __construct(UserRepository $userRepository, PhoneRepository $phoneRepository)
    {
        $this->userRepository = $userRepository;
        $this->phoneRepository = $phoneRepository;
    }

    private function storeApi(array $data): \Illuminate\Http\JsonResponse
    {
        /** @var Phone $phone */
        $phone = $this->phoneRepository->getModelByColumnValue('number', clearPhone($data['phone']));
        if (is_null($phone)) {
            return response()->json([
                'success' => false,
                'data' => [
                    'error' => "Telefon raqam noto'g'ri"
                ]
            ]);
        }

        /** @var User $user */
        $user = $this->userRepository->getModelById($phone->user_id);
        if (is_null($user)) {
            return response()->json([
                'success' => false,
                'data' => [
                    'error' => "Foydalanuvchi telefon raqam bo'yicha topilmadi"
                ]
            ]);
        }

        if (!Hash::check($data['password'], $user->password)) {
            return response()->json([
                'success' => false,
                'data' => [
                    'error' => "Parol noto'g'ri"
                ]
            ]);
        }

        $token = $user->createToken($user->firstname . '-AuthToken')->plainTextToken;
        return response()->json([
            'success' => true,
            'data' => [
                'token' => $token
            ]
        ]);
    }
}

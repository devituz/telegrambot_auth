<?php

namespace App\Repositories\Core;

use App\Models\Phone;
use App\Repositories\BaseRepository;

class PhoneRepository extends BaseRepository
{
    public Phone $phone;

    public function __construct(Phone $phone)
    {
        parent::__construct($phone);
        $this->phone = $phone;
    }

}

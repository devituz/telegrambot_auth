<?php

namespace App\Repositories\Core;

use App\Models\Role;

class RoleRepository
{
    public Role $role;

    public function __construct(Role $role)
    {
        $this->role = $role;
    }

}
